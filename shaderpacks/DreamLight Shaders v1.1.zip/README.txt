DreamLight Shader

A warm, dreamy visual experience for Minecraft.

DreamLight Shader focuses on soft tones, balanced lighting, and smooth performance — perfect for cozy, atmospheric worlds.
It enhances sunlight, skies, and reflections while keeping the look natural and soothing.

Credits

This shader is a remake of Mellow Shader by TheCMK.
Original Mellow Shader: https://www.curseforge.com/minecraft/shaders/mellow

Special thanks to TheCMK for the original creative base and inspiration.