Thank you for using my shader! Below is a list of helpful links, and if you're looking for how to install this shaderpack, any youtube tutorial should work just fine

- Source Code:
  - https://github.com/What42Pizza/I-Like-Vanilla

- Report Issues:
  - https://github.com/What42Pizza/I-Like-Vanilla/issues

- Discord Server (if you want to contact me):
  - https://discord.com/invite/h99ZBex9nZ

- Official Download (Modrinth, recommended):
  - https://modrinth.com/shader/i-like-vanilla

- Official Download (CurseForge):
  - https://www.curseforge.com/minecraft/shaders/i-like-vanilla

- License is bundled with shader files (newer/older licenses only apply to newer/older releases)
