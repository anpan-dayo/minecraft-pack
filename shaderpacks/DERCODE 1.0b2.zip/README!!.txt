RECODERS: _DureXXX_ / M1zora / _Sone4ka_ 


What’s new – changes:

New Aurora [CUTBUG fixed soon]

Fixed Brightness cloud reflections


Other :

SORRY THIS VER NOT HAVE FLOODFILL LIGHT very soon


Full TACZ support. 

Semi PhysicsMod support.

Next UPD :

FloodFill maby

SkyBox

Clouds like BOXY





